from __future__ import annotations

import os
from datetime import datetime

import numpy as np
import pandas as pd
import plotly.express as px
import streamlit as st
from dotenv import load_dotenv

from config import ALL_TICKERS, NAME_MAP, SECTORS
from data_layer import (
    avg_3m_volume,
    build_sector_index,
    download_history,
    download_volume_history,
    fundamentals_for,
    latest_regular_close,
    market_caps,
    market_state,
    pct_change_period,
    return_since,
    twelve_data_quotes,
    yahoo_latest,
)

load_dotenv()

st.set_page_config(page_title="AI Equity Dashboard", page_icon="◈", layout="wide")

st.markdown(
    """
    <style>
    .block-container {padding-top: 1.1rem; padding-bottom: 2rem;}
    div[data-testid="stMetric"] {background: rgba(127,127,127,.06); border: 1px solid rgba(127,127,127,.18); padding: 12px; border-radius: 12px;}
    .small-note {font-size:.82rem; opacity:.72;}
    </style>
    """,
    unsafe_allow_html=True,
)


def fmt_pct(x):
    return "—" if x is None or pd.isna(x) else f"{x:+.2%}"


def fmt_num(x, decimals=2):
    return "—" if x is None or pd.isna(x) else f"{x:,.{decimals}f}"


def fmt_compact(x):
    if x is None or pd.isna(x):
        return "—"
    x = float(x)
    for unit, div in [("T", 1e12), ("B", 1e9), ("M", 1e6), ("K", 1e3)]:
        if abs(x) >= div:
            return f"{x/div:.2f}{unit}"
    return f"{x:,.0f}"


state = market_state()
status_color = "🟢" if state.is_open else "⚪"
td_enabled = bool(os.getenv("TWELVE_DATA_API_KEY", "").strip())

header_l, header_r = st.columns([3, 2])
with header_l:
    st.title("AI Equity Dashboard")
    st.caption("14个AI产业链板块 · 市值加权指数 · 个股行情与估值")
with header_r:
    st.markdown(
        f"**{status_color} Market Status: {state.label}**  \n"
        f"ET {state.now_et.strftime('%Y-%m-%d %H:%M:%S')}  \n"
        f"Realtime source: {'Twelve Data enabled' if td_enabled else 'Yahoo fallback'}"
    )

with st.spinner("加载历史行情与市值数据…"):
    prices = download_history(tuple(ALL_TICKERS), period="5y")
    caps = market_caps(tuple(ALL_TICKERS))

if prices.empty:
    st.error("暂时无法取得历史行情。请检查网络或稍后重试。")
    st.stop()

# ---------- Level 1: sector dashboard ----------
st.subheader("一级：AI产业链板块")
sector_rows = []
sector_series = {}
for sector, members in SECTORS.items():
    tickers = [t for t, _ in members]
    idx = build_sector_index(prices, tickers, caps)
    sector_series[sector] = idx
    latest = float(idx.iloc[-1]) if not idx.empty else None
    daily = idx.pct_change().iloc[-1] if len(idx) >= 2 else None
    total_cap = sum(caps.get(t, 0.0) for t in tickers)
    sector_rows.append({
        "板块": sector,
        "指数": latest,
        "当日": daily,
        "YTD": pct_change_period(idx, ytd=True),
        "1M": pct_change_period(idx, months=1),
        "3M": pct_change_period(idx, months=3),
        "6M": pct_change_period(idx, months=6),
        "1Y": pct_change_period(idx, years=1),
        "总市值": total_cap,
    })

sector_df = pd.DataFrame(sector_rows)
show_sector = sector_df.copy()
show_sector["指数"] = show_sector["指数"].map(lambda x: fmt_num(x, 1))
for c in ["当日", "YTD", "1M", "3M", "6M", "1Y"]:
    show_sector[c] = show_sector[c].map(fmt_pct)
show_sector["总市值"] = show_sector["总市值"].map(fmt_compact)
st.dataframe(show_sector, use_container_width=True, hide_index=True, height=535)

selected_sector = st.selectbox("选择板块查看二级个股", list(SECTORS.keys()), index=0)
selected_members = SECTORS[selected_sector]
selected_tickers = [t for t, _ in selected_members]

# sector chart
idx = sector_series[selected_sector]
if not idx.empty:
    chart_df = idx.rename("Index").reset_index()
    chart_df.columns = ["Date", "Index"]
    fig = px.line(chart_df, x="Date", y="Index", title=f"{selected_sector} — 市值加权指数（Base=1000）")
    fig.update_layout(height=350, margin=dict(l=10, r=10, t=50, b=10), showlegend=False)
    st.plotly_chart(fig, use_container_width=True)

# ---------- Level 2: constituent dashboard ----------
st.subheader("二级：个股明细")

volumes = download_volume_history(tuple(selected_tickers), period="6mo")
fundamentals = fundamentals_for(tuple(selected_tickers))
yahoo_q = yahoo_latest(tuple(selected_tickers))

# Twelve Data only for the selected sector and only while regular session is open.
# This keeps a typical free-plan refresh within a small symbol count.
td_q = twelve_data_quotes(tuple(selected_tickers)) if state.is_open else {}

sector_cap = sum(caps.get(t, 0.0) for t in selected_tickers if caps.get(t, 0.0) > 0)
rows = []
for ticker, configured_name in selected_members:
    hist_last, hist_prev = latest_regular_close(prices, ticker)
    yq = yahoo_q.get(ticker, {})
    td = td_q.get(ticker, {})

    if state.is_open and td:
        try:
            latest_price = float(td.get("close")) if td.get("close") is not None else None
        except Exception:
            latest_price = None
        try:
            prev_close = float(td.get("previous_close")) if td.get("previous_close") is not None else hist_prev
        except Exception:
            prev_close = hist_prev
        try:
            volume = float(td.get("volume")) if td.get("volume") is not None else None
        except Exception:
            volume = None
        source = "Twelve Data"
    elif state.is_open:
        latest_price = yq.get("price") or hist_last
        prev_close = yq.get("previous_close") or hist_prev
        volume = yq.get("volume")
        source = "Yahoo"
    else:
        # After regular close, explicitly display the regular-session close.
        latest_price = yq.get("regular_close") or hist_last
        prev_close = hist_prev
        volume = yq.get("volume")
        source = "Close"

    daily_ret = None
    if latest_price is not None and prev_close not in (None, 0):
        daily_ret = latest_price / prev_close - 1.0

    avg_vol = avg_3m_volume(volumes, ticker)
    vol_ratio = volume / avg_vol if volume is not None and avg_vol not in (None, 0) else None

    s = prices[ticker].dropna() if ticker in prices.columns else pd.Series(dtype=float)
    fp = fundamentals.get(ticker, {}).get("forwardPE")
    name = fundamentals.get(ticker, {}).get("longName") or configured_name
    cap = caps.get(ticker)
    weight = cap / sector_cap if cap and sector_cap else None

    rows.append({
        "Ticker": ticker,
        "Name": name,
        "Price": latest_price,
        "Daily Return": daily_ret,
        "Volume": volume,
        "Vol / 3M Avg": vol_ratio,
        "Forward P/E": fp,
        "YTD Return": return_since(s, latest_price, ytd=True) if latest_price else None,
        "1M Return": return_since(s, latest_price, months=1) if latest_price else None,
        "3M Return": return_since(s, latest_price, months=3) if latest_price else None,
        "6M Return": return_since(s, latest_price, months=6) if latest_price else None,
        "1Y Return": return_since(s, latest_price, years=1) if latest_price else None,
        "3Y Return": return_since(s, latest_price, years=3) if latest_price else None,
        "5Y Return": return_since(s, latest_price, years=5) if latest_price else None,
        "Market Cap": cap,
        "Index Weight": weight,
        "Source": source,
    })

raw_df = pd.DataFrame(rows)
display_df = raw_df.copy()
display_df["Price"] = display_df["Price"].map(lambda x: "—" if x is None or pd.isna(x) else f"${x:,.2f}")
for c in ["Daily Return", "YTD Return", "1M Return", "3M Return", "6M Return", "1Y Return", "3Y Return", "5Y Return", "Index Weight"]:
    display_df[c] = display_df[c].map(fmt_pct)
display_df["Volume"] = display_df["Volume"].map(fmt_compact)
display_df["Vol / 3M Avg"] = display_df["Vol / 3M Avg"].map(lambda x: "—" if x is None or pd.isna(x) else f"{x:.2f}x")
display_df["Forward P/E"] = display_df["Forward P/E"].map(lambda x: "—" if x is None or pd.isna(x) else f"{x:.1f}x")
display_df["Market Cap"] = display_df["Market Cap"].map(fmt_compact)

preferred_order = [
    "Ticker", "Name", "Price", "Daily Return", "Volume", "Vol / 3M Avg", "Forward P/E",
    "YTD Return", "1M Return", "3M Return", "6M Return", "1Y Return", "3Y Return", "5Y Return",
    "Market Cap", "Index Weight", "Source"
]
st.dataframe(display_df[preferred_order], use_container_width=True, hide_index=True, height=330)

st.markdown(
    "<div class='small-note'>"
    "收益率均使用该证券自身的历史价格计算；历史不足则显示“—”。SKHY不会使用000660.KS回填。"
    "板块指数按当前市值推导等效股数并以历史调整价重建，适合作为研究指数；正式指数产品还需维护corporate-action divisor。"
    "</div>",
    unsafe_allow_html=True,
)

with st.expander("数据源与刷新规则"):
    st.markdown(
        """
- **交易时段**：若配置 Twelve Data API key，当前选中板块优先使用 Twelve Data `/quote`；失败自动回退 Yahoo。
- **收盘后**：显示最近一个 regular session 的收盘价，不把盘后成交价当作主价格。
- **历史收益率**：由各 ticker 自身的历史 adjusted price 计算 YTD、1M、3M、6M、1Y、3Y、5Y。
- **成交量比**：当日累计/收盘成交量 ÷ 最近约63个交易日平均成交量。
- **Forward P/E**：Yahoo Finance fundamentals；低频缓存。
- **Market Cap**：Yahoo Finance `fast_info`；低频缓存。
        """
    )
